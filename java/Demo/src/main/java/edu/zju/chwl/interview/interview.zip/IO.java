package edu.zju.chwl.interview;

import java.util.List;

/**
 * 读取指定目录下指定类型的文件
 * 找出文件中最长的单词，并找出想应的文件
 * @author chwl
 * @Date 2015年9月2日 上午12:18:14
 */
public class IO {
	class ResultType{
		String longWord;
		List<String> fileNameList;
		public ResultType(String longWord,List<String> fileNameList) {
			this.longWord=longWord;
			this.fileNameList=fileNameList;
		}
	}
	
	/**
	 * 
	 * @param directory "C:\temp"
	 * @param extension "txt"
	 * @return
	 */
	public ResultType findLongestWord(String directory,String extension){
		//TODO
		return null;
	}

}
