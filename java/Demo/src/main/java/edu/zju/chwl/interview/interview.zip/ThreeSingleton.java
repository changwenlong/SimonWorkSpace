package edu.zju.chwl.interview;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * 知道单例模式吗？
 * 扩展单例模式，控制实际产生实例数目为 3 个
 */
public class ThreeSingleton {
	private final static String DEFAULT_PREKEY = "cache";// 为后面使用的 key 定义一个前缀
	private static Map<String, ThreeSingleton> map = new HashMap<String, ThreeSingleton>();// 定义缓存实例的容器
	private static int number = 1;// 定义初始化实例数目为 1
	private final static int NUM_MAX = 3;

	private ThreeSingleton() {

	}

	public static synchronized ThreeSingleton getInstance() {
		// 通过缓存理念及方式控制数量
		String key = DEFAULT_PREKEY + number;
		ThreeSingleton threeSingleton = map.get(key);
		if (threeSingleton == null) {
			threeSingleton = new ThreeSingleton();
			map.put(key, threeSingleton);
		}
		number++;// 实例数目加 1
		if (number > NUM_MAX) {
			number = 1;
		}
		return threeSingleton;
	}

	public static void main(String args[]) {
		ThreeSingleton t1 = getInstance();
		ThreeSingleton t2 = getInstance();
		ThreeSingleton t3 = getInstance();
		ThreeSingleton t4 = getInstance();
		ThreeSingleton t5 = getInstance();
		ThreeSingleton t6 = getInstance();
		HashSet<ThreeSingleton> set = new HashSet<ThreeSingleton>();
		set.add(t1);
		set.add(t2);
		set.add(t3);
		set.add(t4);
		set.add(t5);
		set.add(t6);
		System.out.println(set.size() == 3);
	}
}
